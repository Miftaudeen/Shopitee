package com.example.shopitee

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_cart.*

class CartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        val adapter = CartAdapter()
        recycle.adapter = adapter
        recycle.layoutManager = LinearLayoutManager(this)
        recycle.setHasFixedSize(true)
    }
}