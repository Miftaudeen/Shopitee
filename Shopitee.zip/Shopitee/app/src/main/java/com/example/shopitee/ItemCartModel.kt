package com.example.shopitee

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_table")
data class ItemCartModel(
        val image: Int = R.mipmap.milk_bottles,
        val name: String = "Milk",
        val price: String = "₦1250/-"
) {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

}